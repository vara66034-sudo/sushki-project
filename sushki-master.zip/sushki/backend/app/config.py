DATA_DIR = "data"
VECTOR_STORE_DIR = "vector_store"

CHUNK_SIZE = 500
CHUNK_OVERLAP = 100
TOP_K = 5

HF_MODEL_NAME = "sentence-transformers/paraphrase-multilingual-mpnet-base-v2"

GIGACHAT_CREDENTIALS = "MDE5YWJhNTEtN2EzYi03NWViLWEwNmQtN2YzM2MzNjRjY2NiOjMzY2MxY2NkLWFjN2EtNDM2Mi1hMjUyLTkzOGVjZmJmMjQ2Nw=="
